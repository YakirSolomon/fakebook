var x=1;
var y=1;
console.log(x);
for(i=1;i<11;i++){
    console.log(x);
    z=x
    x=y+x;
    y=z;

}

